'use strict';

module.exports = {
    port: '8080',
};
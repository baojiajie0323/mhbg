module.exports = {
  oracle: {
    user          : "mh01",
    password      : "mh01",
    connectString : "116.246.2.202:1521/TOPPROD"
  }
};
